$('img').click(function(){
    $(this).hide("slow");
})
$('#restore').click(function(){
    $('img').show();
})